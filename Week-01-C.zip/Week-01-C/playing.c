#include <stdio.h>
#include <cs50.h>

void countera(int n)
    {
       for (int i = 1;  i <= n; i++)
       {
           printf("\n %i",  i);
       }
    }
    
int positive(void)
{
    int i;
    do
    {
        i = get_int("Diga um numero: ");
    }
    while (i < 0);
    return i;
}
    
int main(void)
{
    
    //using function
    positive();
    
    //Greet user
    printf("Hello, World \n");
    
    //getting users name
    string name = get_string("What is your name?");
    printf("My name is %s too!\n", name);
    
    // Loups with while
    int counter = 0;
    while (counter <= 2)
    {
        printf("%i de 02\n", counter);
        counter++;
    }
    
    // Comparing charactes
    char a = get_char("Do tou agree?");
    if (a == 'y' || a == 'Y')
    {
        printf("Agreed.");
    }
    else if (a == 'n' || a == 'N')
    {
        printf("Not Agreed.");
    }
    
    // Loups with for and functions
    
     countera(30);
    
    // Doing math
    int x = get_int("%s,  please, tell me a number for x: ", name);
    int y = get_int("\nNow, for y: ");
    printf("\n The some of X and Y is: %i", x + y);
    
    if (x + y > 5)
    {
        printf("A soma dos números é maior que 5");
    }
    else 
    {
        printf("A soma dos números é menor que 5");
    }
}