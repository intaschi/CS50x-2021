#include <stdio.h>
#include <cs50.h>

int get_positive(void)
{
    int n;
    do
    {
        n = get_int("Diga um numero: ");
    }
    while (n <= 0);
    return n;
}

int main(void)
{
    // get the hight of the pyramid by user
    int x = get_positive();
    
    //contruct pyramid
    
    for (int i = 0; i < x; i++)
    {
        // print spaces
        for (int l = 0; l < x-i-1; l++)
        {
            printf(" ");
        }
        
        //print blocks first pyramid
        for (int l = 0; l < i+1; l++)
        {
            printf("#");
        }
        
        //print spaces
        printf("  ");
        
        // print blocks second pyramid
        for (int l = 0; l < i+1; l++)
        {
            printf("#");
        }
        printf("\n");
    }
    
}